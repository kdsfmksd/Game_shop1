<?php
session_start();
require 'db.php';

// Получаем ID игры из URL
$game_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ищем игру в БД
$stmt = $pdo->prepare("SELECT * FROM games WHERE id = ?");
$stmt->execute([$game_id]);
$game = $stmt->fetch();

if (!$game) {
    die("Игра не найдена!"); // Если в URL передали несуществующий ID
}

$message = '';

// Обработка добавления в корзину
if (isset($_POST['add_to_cart']) && isset($_SESSION['user_id'])) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    // Добавляем ID игры в корзину (сессию)
    $_SESSION['cart'][] = $game['id'];
    $message = "Игра добавлена в корзину!";
}

// Обработка добавления отзыва
if (isset($_POST['add_review']) && isset($_SESSION['user_id'])) {
    $comment = trim($_POST['comment']);
    if (!empty($comment)) {
        $stmt = $pdo->prepare("INSERT INTO reviews (user_id, game_id, comment) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $game_id, $comment]);
        header("Location: game.php?id=" . $game_id);
        exit;
    }
}

// Получаем отзывы с именами пользователей (через JOIN)
$stmt = $pdo->prepare("
    SELECT reviews.*, users.username 
    FROM reviews 
    JOIN users ON reviews.user_id = users.id 
    WHERE game_id = ? 
    ORDER BY created_at DESC
");
$stmt->execute([$game_id]);
$reviews = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($game['title']) ?> - GameShop</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Главная</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <?php if($_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php">⚙ Панель админа</a>
                <?php else: ?>
                    <a href="cart.php">🛒 Корзина</a>
                <?php endif; ?>
                <a href="logout.php">Выход (<?= htmlspecialchars($_SESSION['username']) ?>)</a>
            <?php else: ?>
                <a href="login.php">Вход</a>
                <a href="register.php">Регистрация</a>
            <?php endif; ?>
        </nav>
        <a href="index.php" class="logo">GameShop</a>
    </header>

    <div class="container">
        <?php if ($message): ?>
            <div class="success-msg"><?= $message ?></div>
        <?php endif; ?>

        <!-- Информация об игре -->
        <div class="game-details">
            <img src="img/<?= htmlspecialchars($game['image']) ?>" alt="<?= htmlspecialchars($game['title']) ?>" onerror="this.src='https://via.placeholder.com/300x400?text=No+Image'">
            <div class="game-info">
                <h1><?= htmlspecialchars($game['title']) ?></h1>
                <p><strong>Платформа:</strong> <?= htmlspecialchars($game['platform']) ?></p>
                <p><strong>Описание:</strong><br><?= nl2br(htmlspecialchars($game['description'])) ?></p>
                <div class="price"><?= number_format($game['price'], 0, '', ' ') ?> ₽</div>
                
                <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] !== 'admin'): ?>
                    <form method="POST">
                        <button type="submit" name="add_to_cart" class="btn" style="width: 200px;">🛒 В корзину</button>
                    </form>
                <?php elseif (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin'): ?>
                    <p style="color: #cf6679;">Администраторы не могут совершать покупки.</p>
                <?php else: ?>
                    <p><a href="login.php" style="color: #bb86fc;">Войдите</a>, чтобы купить игру.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Секция отзывов -->
        <div class="reviews-section">
            <h2>Отзывы</h2>
            
            <!-- Форма для отзыва (только для авторизованных) -->
            <?php if (isset($_SESSION['user_id'])): ?>
                <form method="POST" style="margin-bottom: 20px;">
                    <textarea name="comment" placeholder="Напишите свой отзыв..." required style="width: 100%; height: 80px; padding: 10px; background: #2c2c2c; color: white; border: 1px solid #444; border-radius: 4px; box-sizing: border-box;"></textarea>
                    <button type="submit" name="add_review" class="btn" style="width: 200px; margin-top: 10px;">Отправить отзыв</button>
                </form>
            <?php else: ?>
                <p>Оставлять отзывы могут только <a href="login.php" style="color: #bb86fc;">авторизованные</a> пользователи.</p>
            <?php endif; ?>

            <!-- Список отзывов -->
            <?php if (count($reviews) > 0): ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review-card">
                        <small><?= date('d.m.Y H:i', strtotime($review['created_at'])) ?></small>
                        <strong><?= htmlspecialchars($review['username']) ?></strong>
                        <p style="margin-top: 10px;"><?= nl2br(htmlspecialchars($review['comment'])) ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Пока нет отзывов. Станьте первым!</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
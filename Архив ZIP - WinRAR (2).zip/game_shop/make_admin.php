<?php
require 'db.php';

$username = 'Admin';
$password = 'Admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);

try {
    // Сначала на всякий случай удаляем старого, если он там есть
    $pdo->query("DELETE FROM users WHERE username = 'Admin'");
    
    // Добавляем нового админа
    $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'admin')");
    $stmt->execute([$username, $hash]);
    
    echo "<h1>Готово!</h1><p>Админ успешно создан!</p><p>Логин: <b>Admin</b><br>Пароль: <b>Admin123</b></p>";
    echo '<a href="login.php">Перейти на страницу входа</a>';
} catch (Exception $e) {
    echo "Ошибка: " . $e->getMessage();
}
?>
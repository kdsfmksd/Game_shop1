<?php
session_start();
session_destroy(); // Уничтожаем сессию (разлогиниваем)
?>
<!-- Железобетонный редирект на главную -->
<script>
    window.location.href = 'index.php';
</script>
<?php
session_start();
require 'db.php';


if (!isset($_SESSION['user_id']) || (isset($_SESSION['role']) && $_SESSION['role'] === 'admin')) {
    die("Доступ запрещен. Авторизуйтесь как обычный пользователь.");
}

$success = '';

// Оформление заказа (Визуальная оплата)
if (isset($_POST['checkout']) && !empty($_SESSION['cart'])) {
    $total = $_POST['total_price'];
    
    // Записываем заказ в БД
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_price, status) VALUES (?, ?, 'Оплачен')");
    $stmt->execute([$_SESSION['user_id'], $total]);
    
    // Очищаем корзину
    $_SESSION['cart'] = [];
    $success = "Оплата прошла успешно! Ваш заказ оформлен.";
}

// Очистка корзины вручную
if (isset($_POST['clear_cart'])) {
    $_SESSION['cart'] = [];
}

// Получаем данные игр из корзины
$cart_items = [];
$total_price = 0;

if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $id) {
        $stmt = $pdo->prepare("SELECT * FROM games WHERE id = ?");
        $stmt->execute([$id]);
        $game = $stmt->fetch();
        if ($game) {
            $cart_items[] = $game;
            $total_price += $game['price'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Корзина - GameShop</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .cart-item { display: flex; justify-content: space-between; padding: 10px; border-bottom: 1px solid #333; }
        .cart-total { font-size: 24px; text-align: right; margin: 20px 0; color: #bb86fc; }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Главная</a>
            <a href="logout.php">Выход (<?= htmlspecialchars($_SESSION['username']) ?>)</a>
        </nav>
        <a href="index.php" class="logo">GameShop</a>
    </header>

    <div class="container">
        <h1>Ваша корзина</h1>
        
        <?php if ($success): ?>
            <div class="success-msg"><?= $success ?></div>
        <?php endif; ?>

        <div style="background: #1e1e1e; padding: 20px; border-radius: 8px;">
            <?php if (count($cart_items) > 0): ?>
                <?php foreach ($cart_items as $item): ?>
                    <div class="cart-item">
                        <span><?= htmlspecialchars($item['title']) ?> (<?= htmlspecialchars($item['platform']) ?>)</span>
                        <span><?= number_format($item['price'], 0, '', ' ') ?> ₽</span>
                    </div>
                <?php endforeach; ?>
                
                <div class="cart-total">Итого: <?= number_format($total_price, 0, '', ' ') ?> ₽</div>
                
                <form method="POST" style="display: flex; justify-content: space-between;">
                    <input type="hidden" name="total_price" value="<?= $total_price ?>">
                    <button type="submit" name="clear_cart" class="btn" style="width: 200px; background: #cf6679;">Очистить корзину</button>
                    <button type="submit" name="checkout" class="btn" style="width: 200px; background: #4CAF50; color: white;">💳 Оплатить</button>
                </form>
            <?php else: ?>
                <p>Ваша корзина пуста.</p>
                <a href="index.php" class="btn" style="display: inline-block; width: 200px; text-align: center; text-decoration: none;">Перейти в каталог</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
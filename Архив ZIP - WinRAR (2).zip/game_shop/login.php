<?php
session_start();
require 'db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // Ищем пользователя по логину
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    // Проверяем, существует ли пользователь и совпадает ли пароль
    if ($user && password_verify($password, $user['password'])) {
        
        // ПРОВЕРКА НА БАН
        if ($user['is_banned'] == 1) {
            $error = "Ваш аккаунт заблокирован администратором.";
        } else {
            // Если не забанен, записываем данные в сессию
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // Перенаправляем на главную
            header("Location: index.php");
            exit;
        }
    } else {
        $error = "Неверный логин или пароль!";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Главная</a>
            <a href="register.php">Регистрация</a>
        </nav>
        <!-- Название сайта справа -->
        <a href="index.php" class="logo">GameShop</a>
    </header>

    <div class="form-box">
        <h2>Вход</h2>
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        <form method="POST">
            <!-- Отключаем автозаполнение -->
            <input type="text" name="username" placeholder="Логин" autocomplete="off" required>
            <input type="password" name="password" placeholder="Пароль" autocomplete="new-password" required>
            
            <button type="submit" class="btn">Войти</button>
        </form>
    </div>
</body>
</html>
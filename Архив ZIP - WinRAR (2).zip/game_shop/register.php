<?php
session_start();
require 'db.php'; // Подключаем базу данных

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if (!empty($username) && !empty($password)) {
        // Шифруем пароль
        $hash = password_hash($password, PASSWORD_DEFAULT);
        try {
            // Пытаемся добавить в БД (по умолчанию is_banned = 0, role = user)
            $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->execute([$username, $hash]);
            // Если успешно - кидаем на страницу входа
            header("Location: login.php");
            exit;
        } catch (PDOException $e) {
            $error = "Такой логин уже занят!";
        }
    } else {
        $error = "Заполните все поля!";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Главная</a>
            <a href="login.php">Вход</a>
        </nav>
        <!-- Название сайта справа -->
        <a href="index.php" class="logo">GameShop</a>
    </header>

    <div class="form-box">
        <h2>Регистрация</h2>
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        <form method="POST">
            <!-- Поля ввода возвращены на место, с защитой от автозаполнения -->
            <input type="text" name="username" placeholder="Логин" autocomplete="off" required>
            <input type="password" name="password" placeholder="Пароль" autocomplete="new-password" required>
            <button type="submit" class="btn">Зарегистрироваться</button>
        </form>
    </div>
</body>
</html>
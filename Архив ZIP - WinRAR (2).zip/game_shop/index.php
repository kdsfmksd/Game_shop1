<?php
session_start();
require 'db.php';

// Реализация поиска
$search = '';
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    // Ищем игры, где в названии есть введенный текст
    $stmt = $pdo->prepare("SELECT * FROM games WHERE title LIKE ?");
    $stmt->execute(["%$search%"]);
} else {
    // Если поиска нет, выводим все игры
    $stmt = $pdo->query("SELECT * FROM games");
}
$games = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>GameShop - Каталог игр</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Главная</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <?php if($_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php">⚙ Панель админа</a>
                <?php else: ?>
                    <a href="cart.php">🛒 Корзина</a>
                <?php endif; ?>
                <a href="logout.php">Выход (<?= htmlspecialchars($_SESSION['username']) ?>)</a>
            <?php else: ?>
                <a href="login.php">Вход</a>
                <a href="register.php">Регистрация</a>
            <?php endif; ?>
        </nav>
        <a href="index.php" class="logo">GameShop</a>
    </header>

    <div class="container">
        <!-- Форма поиска -->
        <form method="GET" class="search-form">
            <input type="text" name="search" placeholder="Поиск игр по названию..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn">Найти</button>
        </form>

        <!-- Сетка товаров -->
        <div class="games-grid">
            <?php if (count($games) > 0): ?>
                <?php foreach ($games as $game): ?>
                    <div class="game-card">
                        <!-- Если картинка есть в папке img, показываем ее, иначе заглушку -->
                        <img src="img/<?= htmlspecialchars($game['image']) ?>" alt="<?= htmlspecialchars($game['title']) ?>" onerror="this.src='https://via.placeholder.com/300x400?text=No+Image'">
                        <h3><?= htmlspecialchars($game['title']) ?></h3>
                        <p>Платформа: <?= htmlspecialchars($game['platform']) ?></p>
                        <div class="price"><?= number_format($game['price'], 0, '', ' ') ?> ₽</div>
                        <a href="game.php?id=<?= $game['id'] ?>" class="btn" style="display: block; text-decoration: none; text-align: center;">Подробнее</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Игры не найдены.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
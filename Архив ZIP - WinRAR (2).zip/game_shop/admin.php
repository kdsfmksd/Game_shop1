<?php
session_start();
require 'db.php';

// Защита страницы: пускаем ТОЛЬКО админа
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Доступ закрыт. Вы не являетесь администратором.");
}

$msg = '';

// ДОБАВЛЕНИЕ ИГРЫ
if (isset($_POST['add_game'])) {
    $title = trim($_POST['title']);
    $desc = trim($_POST['description']);
    $price = (int)$_POST['price'];
    $platform = trim($_POST['platform']);
    
    $image_name = 'default.jpg'; // Картинка по умолчанию
    
    // Обработка загрузки файла
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        // Генерируем уникальное имя файла, чтобы не перезаписать существующие
        $image_name = time() . '_' . basename($_FILES['image']['name']);
        $upload_path = 'img/' . $image_name;
        
        // Перемещаем загруженный файл из временной папки в нашу img/
        move_uploaded_file($_FILES['image']['tmp_name'], $upload_path);
    }
    
    $stmt = $pdo->prepare("INSERT INTO games (title, description, price, platform, image) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$title, $desc, $price, $platform, $image_name]);
    $msg = "Игра успешно добавлена!";
}

// УДАЛЕНИЕ ИГРЫ
if (isset($_POST['delete_game'])) {
    $id = (int)$_POST['game_id'];
    $stmt = $pdo->prepare("DELETE FROM games WHERE id = ?");
    $stmt->execute([$id]);
    $msg = "Игра удалена!";
}

// БАН / РАЗБАН ПОЛЬЗОВАТЕЛЯ
if (isset($_POST['toggle_ban'])) {
    $user_id = (int)$_POST['user_id'];
    $current_status = (int)$_POST['current_status'];
    $new_status = $current_status === 1 ? 0 : 1;
    
    $stmt = $pdo->prepare("UPDATE users SET is_banned = ? WHERE id = ?");
    $stmt->execute([$new_status, $user_id]);
    $msg = "Статус пользователя обновлен!";
}

// Получаем все игры и всех пользователей для таблиц
$games = $pdo->query("SELECT * FROM games ORDER BY id DESC")->fetchAll();
$users = $pdo->query("SELECT * FROM users WHERE role = 'user' ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель Администратора</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Стили для админских таблиц */
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #444; padding: 10px; text-align: left; }
        th { background-color: #2c2c2c; color: #bb86fc; }
        .admin-section { background: #1e1e1e; padding: 20px; border-radius: 8px; margin-bottom: 30px; }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Главная (Каталог)</a>
            <a href="logout.php">Выход (Админ)</a>
        </nav>
        <a href="index.php" class="logo">GameShop</a>
    </header>

    <div class="container">
        <h1>Панель управления</h1>
        
        <?php if ($msg): ?>
            <div class="success-msg"><?= $msg ?></div>
        <?php endif; ?>

        <!-- Форма добавления игры -->
        <div class="admin-section">
            <h2>Добавить новую игру</h2>
            <!-- enctype="multipart/form-data" обязателен для загрузки файлов -->
            <form method="POST" enctype="multipart/form-data">
                <input type="text" name="title" placeholder="Название игры" required>
                <textarea name="description" placeholder="Описание" required style="width: 100%; height: 60px; padding: 10px; background: #2c2c2c; color: white; border: 1px solid #444; margin: 10px 0;"></textarea>
                <input type="number" name="price" placeholder="Цена (в рублях)" required>
                <input type="text" name="platform" placeholder="Платформа (PC, PS5 и т.д.)" required>
                
                <label style="display: block; margin: 10px 0;">Обложка игры:</label>
                <input type="file" name="image" accept="image/*" required style="background: none; border: none; padding: 0;">
                
                <button type="submit" name="add_game" class="btn">Добавить в каталог</button>
            </form>
        </div>

        <!-- Управление пользователями -->
        <div class="admin-section">
            <h2>Управление пользователями</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Логин</th>
                    <th>Статус</th>
                    <th>Действие</th>
                </tr>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td><?= $u['id'] ?></td>
                        <td><?= htmlspecialchars($u['username']) ?></td>
                        <td><?= $u['is_banned'] ? '<span style="color:#cf6679;">Забанен</span>' : '<span style="color:#4CAF50;">Активен</span>' ?></td>
                        <td>
                            <form method="POST" style="margin:0;">
                                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                <input type="hidden" name="current_status" value="<?= $u['is_banned'] ?>">
                                <button type="submit" name="toggle_ban" class="btn" style="margin:0; padding: 5px; width: 120px; background: <?= $u['is_banned'] ? '#4CAF50' : '#cf6679' ?>;">
                                    <?= $u['is_banned'] ? 'Разбанить' : 'Забанить' ?>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <!-- Управление играми -->
        <div class="admin-section">
            <h2>Существующие игры</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Название</th>
                    <th>Цена</th>
                    <th>Действие</th>
                </tr>
                <?php foreach ($games as $g): ?>
                    <tr>
                        <td><?= $g['id'] ?></td>
                        <td><?= htmlspecialchars($g['title']) ?></td>
                        <td><?= $g['price'] ?> ₽</td>
                        <td>
                            <form method="POST" style="margin:0;">
                                <input type="hidden" name="game_id" value="<?= $g['id'] ?>">
                                <button type="submit" name="delete_game" class="btn" style="margin:0; padding: 5px; width: 100px; background: #cf6679;" onclick="return confirm('Точно удалить?');">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body>
</html>